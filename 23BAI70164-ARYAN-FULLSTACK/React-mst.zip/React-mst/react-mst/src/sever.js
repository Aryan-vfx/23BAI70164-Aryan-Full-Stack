const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// Fake database (in-memory)
let products = [
  { id: 1, name: "Laptop", price: 50000 },
  { id: 2, name: "Phone", price: 20000 }
];

// GET all products
app.get("/api/products", (req, res) => {
  res.json(products);
});

// POST new product
app.post("/api/products", (req, res) => {
  const { name, price } = req.body;
  if (!name || !price) {
    return res.status(400).json({ error: "Invalid data" });
  }
  const newProduct = {
    id: products.length + 1,
    name,
    price: parseFloat(price)
  };
  products.push(newProduct);
  res.json({ message: "Product added", product: newProduct });
});

app.listen(5000, () => console.log("Server running on http://localhost:5000"));

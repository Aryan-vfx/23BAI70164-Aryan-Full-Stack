import React, { useState } from "react";

function App() {
  // "Database" simulated with useState
  const [products, setProducts] = useState([
    { id: 1, name: "Laptop", price: 50000 },
    { id: 2, name: "Phone", price: 20000 }
  ]);

  // Form states
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");

  // Handle form submit
  const handleAddProduct = (e) => {
    e.preventDefault();

    // Validate
    if (!name || !price) {
      alert("Please enter both name and price!");
      return;
    }

    // Create new product
    const newProduct = {
      id: products.length + 1,
      name,
      price: parseFloat(price)
    };

    // Update "database"
    setProducts([...products, newProduct]);

    // Reset form
    setName("");
    setPrice("");
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h2>📦 Product List</h2>
      {products.length > 0 ? (
        <ul>
          {products.map((p) => (
            <li key={p.id}>
              {p.id}. {p.name} — ₹{p.price}
            </li>
          ))}
        </ul>
      ) : (
        <p>No products available</p>
      )}

      <h3>Add New Product</h3>
      <form onSubmit={handleAddProduct}>
        <input
          type="text"
          placeholder="Product Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          style={{ marginRight: "10px" }}
        />
        <input
          type="number"
          placeholder="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          style={{ marginRight: "10px" }}
        />
        <button type="submit">Add</button>
      </form>
    </div>
  );
}

export default App;
